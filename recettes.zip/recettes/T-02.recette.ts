import { describe, expect, it } from 'vitest';
import { construireApp } from '../../src/app';

const MAINTENANT = new Date('2026-06-15T10:00:00Z');
const alice = { 'x-user-id': 'alice', 'x-role': 'employe' };
const bob = { 'x-user-id': 'bob', 'x-role': 'manager' };
const diane = { 'x-user-id': 'diane', 'x-role': 'directeur' };
const carl = { 'x-user-id': 'carl', 'x-role': 'comptable' };
type H = Record<string, string>;

function ligne(s: Record<string, unknown> = {}) {
  return { date: '2026-06-10', categorie: 'transport', montantHT: 1000, tauxTVA: 20, justificatif: true, libelle: 'Test', ...s };
}
async function noteAvecLignes(app: ReturnType<typeof construireApp>, h: H, lignes: object[], soumettre = false) {
  const { id } = (await app.inject({ method: 'POST', url: '/notes', headers: h })).json();
  for (const l of lignes) {
    const r = await app.inject({ method: 'POST', url: `/notes/${id}/lignes`, headers: h, payload: l });
    if (r.statusCode !== 201) throw new Error(`ligne refusée: ${r.body}`);
  }
  if (soumettre) await app.inject({ method: 'POST', url: `/notes/${id}/soumettre`, headers: h });
  return id as string;
}
const nouvelle = () => construireApp(() => MAINTENANT);

describe('T-02 arrondi de la TVA', () => {
  const total = async (ht: number, taux: number) => {
    const app = nouvelle();
    const id = await noteAvecLignes(app, alice, [ligne({ montantHT: ht, tauxTVA: taux })]);
    return (await app.inject({ method: 'GET', url: `/notes/${id}`, headers: alice })).json().totalTTC;
  };
  it('1999 à 5,5 % donne 2109', async () => { expect(await total(1999, 5.5)).toBe(2109); });
  it('10 à 5,5 % donne 11', async () => { expect(await total(10, 5.5)).toBe(11); });
  it('les montants ronds ne changent pas', async () => { expect(await total(10000, 20)).toBe(12000); });
  it('0 % ne change rien', async () => { expect(await total(1234, 0)).toBe(1234); });
  it('arrondi à la baisse en dessous de 0,5', async () => { expect(await total(1001, 10)).toBe(1101); });
});
