import { describe, expect, it } from 'vitest';
import { construireApp } from '../../src/app';

const MAINTENANT = new Date('2026-06-15T10:00:00Z');
const alice = { 'x-user-id': 'alice', 'x-role': 'employe' };
const bob = { 'x-user-id': 'bob', 'x-role': 'manager' };
const diane = { 'x-user-id': 'diane', 'x-role': 'directeur' };
const carl = { 'x-user-id': 'carl', 'x-role': 'comptable' };
type H = Record<string, string>;

function ligne(s: Record<string, unknown> = {}) {
  return { date: '2026-06-10', categorie: 'transport', montantHT: 1000, tauxTVA: 20, justificatif: true, libelle: 'Test', ...s };
}
async function noteAvecLignes(app: ReturnType<typeof construireApp>, h: H, lignes: object[], soumettre = false) {
  const { id } = (await app.inject({ method: 'POST', url: '/notes', headers: h })).json();
  for (const l of lignes) {
    const r = await app.inject({ method: 'POST', url: `/notes/${id}/lignes`, headers: h, payload: l });
    if (r.statusCode !== 201) throw new Error(`ligne refusée: ${r.body}`);
  }
  if (soumettre) await app.inject({ method: 'POST', url: `/notes/${id}/soumettre`, headers: h });
  return id as string;
}
const nouvelle = () => construireApp(() => MAINTENANT);

describe('T-01 péage', () => {
  it('accepte 40,00 € TTC et refuse 40,01 €', async () => {
    const app = nouvelle();
    const { id } = (await app.inject({ method: 'POST', url: '/notes', headers: alice })).json();
    const ok = await app.inject({ method: 'POST', url: `/notes/${id}/lignes`, headers: alice, payload: ligne({ categorie: 'peage', montantHT: 3333, tauxTVA: 20 }) });
    expect(ok.statusCode).toBe(201);
    const ko = await app.inject({ method: 'POST', url: `/notes/${id}/lignes`, headers: alice, payload: ligne({ categorie: 'peage', montantHT: 4001, tauxTVA: 0 }) });
    expect(ko.statusCode).toBe(422);
    expect(ko.json().code).toBe('LIGNE_PLAFOND_DEPASSE');
  });
  it('exige un justificatif au-dessus de 25,00 €', async () => {
    const app = nouvelle();
    const { id } = (await app.inject({ method: 'POST', url: '/notes', headers: alice })).json();
    const r = await app.inject({ method: 'POST', url: `/notes/${id}/lignes`, headers: alice, payload: ligne({ categorie: 'peage', montantHT: 3000, tauxTVA: 0, justificatif: false }) });
    expect(r.json().code).toBe('LIGNE_JUSTIFICATIF_MANQUANT');
  });
  it('ne change pas les catégories existantes', async () => {
    const app = nouvelle();
    const { id } = (await app.inject({ method: 'POST', url: '/notes', headers: alice })).json();
    const r = await app.inject({ method: 'POST', url: `/notes/${id}/lignes`, headers: alice, payload: ligne({ categorie: 'autre', montantHT: 5001, tauxTVA: 0 }) });
    expect(r.json().code).toBe('LIGNE_PLAFOND_DEPASSE');
  });
});
