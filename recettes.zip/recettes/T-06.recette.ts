import { describe, expect, it } from 'vitest';
import { construireApp } from '../../src/app';

const MAINTENANT = new Date('2026-06-15T10:00:00Z');
const alice = { 'x-user-id': 'alice', 'x-role': 'employe' };
const bob = { 'x-user-id': 'bob', 'x-role': 'manager' };
const diane = { 'x-user-id': 'diane', 'x-role': 'directeur' };
const carl = { 'x-user-id': 'carl', 'x-role': 'comptable' };
type H = Record<string, string>;

function ligne(s: Record<string, unknown> = {}) {
  return { date: '2026-06-10', categorie: 'transport', montantHT: 1000, tauxTVA: 20, justificatif: true, libelle: 'Test', ...s };
}
async function noteAvecLignes(app: ReturnType<typeof construireApp>, h: H, lignes: object[], soumettre = false) {
  const { id } = (await app.inject({ method: 'POST', url: '/notes', headers: h })).json();
  for (const l of lignes) {
    const r = await app.inject({ method: 'POST', url: `/notes/${id}/lignes`, headers: h, payload: l });
    if (r.statusCode !== 201) throw new Error(`ligne refusée: ${r.body}`);
  }
  if (soumettre) await app.inject({ method: 'POST', url: `/notes/${id}/soumettre`, headers: h });
  return id as string;
}
const nouvelle = () => construireApp(() => MAINTENANT);

describe('T-06 export CSV', () => {
  it('réservé au comptable', async () => {
    const r = await nouvelle().inject({ method: 'GET', url: '/export/notes.csv', headers: bob });
    expect(r.statusCode).toBe(403);
  });
  it('en-tête seul sans note approuvée', async () => {
    const app = nouvelle();
    await noteAvecLignes(app, alice, [ligne()], true);
    const r = await app.inject({ method: 'GET', url: '/export/notes.csv', headers: carl });
    expect(r.statusCode).toBe(200);
    expect(r.body.trim()).toBe('note;employe;date;categorie;libelle;montantHT;tva;montantTTC');
  });
  it('exporte les lignes approuvées avec échappement', async () => {
    const app = nouvelle();
    const id = await noteAvecLignes(app, alice, [ligne({ libelle: 'Déjeuner; client "Dupont"', montantHT: 1000, tauxTVA: 20 }), ligne({ libelle: 'Taxi', montantHT: 500, tauxTVA: 10, categorie: 'transport' })], true);
    await app.inject({ method: 'POST', url: `/notes/${id}/approuver`, headers: bob });
    await noteAvecLignes(app, alice, [ligne({ libelle: 'Non approuvée' })], true);
    const r = await app.inject({ method: 'GET', url: '/export/notes.csv', headers: carl });
    const lignes = r.body.split('\n').filter(Boolean);
    expect(lignes).toEqual([
      'note;employe;date;categorie;libelle;montantHT;tva;montantTTC',
      `${id};alice;2026-06-10;transport;"Déjeuner; client ""Dupont""";1000;200;1200`,
      `${id};alice;2026-06-10;transport;Taxi;500;50;550`,
    ]);
  });
});
