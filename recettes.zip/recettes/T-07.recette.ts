import { describe, expect, it } from 'vitest';
import { construireApp } from '../../src/app';

const MAINTENANT = new Date('2026-06-15T10:00:00Z');
const alice = { 'x-user-id': 'alice', 'x-role': 'employe' };
const bob = { 'x-user-id': 'bob', 'x-role': 'manager' };
const diane = { 'x-user-id': 'diane', 'x-role': 'directeur' };
const carl = { 'x-user-id': 'carl', 'x-role': 'comptable' };
type H = Record<string, string>;

function ligne(s: Record<string, unknown> = {}) {
  return { date: '2026-06-10', categorie: 'transport', montantHT: 1000, tauxTVA: 20, justificatif: true, libelle: 'Test', ...s };
}
async function noteAvecLignes(app: ReturnType<typeof construireApp>, h: H, lignes: object[], soumettre = false) {
  const { id } = (await app.inject({ method: 'POST', url: '/notes', headers: h })).json();
  for (const l of lignes) {
    const r = await app.inject({ method: 'POST', url: `/notes/${id}/lignes`, headers: h, payload: l });
    if (r.statusCode !== 201) throw new Error(`ligne refusée: ${r.body}`);
  }
  if (soumettre) await app.inject({ method: 'POST', url: `/notes/${id}/soumettre`, headers: h });
  return id as string;
}
const nouvelle = () => construireApp(() => MAINTENANT);

describe('T-07 commentaire', () => {
  const ajouter = async (commentaire?: string) => {
    const app = nouvelle();
    const { id } = (await app.inject({ method: 'POST', url: '/notes', headers: alice })).json();
    const r = await app.inject({ method: 'POST', url: `/notes/${id}/lignes`, headers: alice, payload: ligne(commentaire === undefined ? {} : { commentaire }) });
    return { r, app, id };
  };
  it('accepte 200 caractères et les renvoie', async () => {
    const { r } = await ajouter('a'.repeat(200));
    expect(r.statusCode).toBe(201);
    expect(r.json().lignes[0].commentaire).toBe('a'.repeat(200));
  });
  it('refuse 201 caractères', async () => {
    const { r } = await ajouter('a'.repeat(201));
    expect(r.statusCode).toBe(422);
    expect(r.json().code).toBe('LIGNE_COMMENTAIRE_TROP_LONG');
  });
  it('ne renvoie pas un commentaire absent ou vide', async () => {
    const sans = await ajouter();
    expect('commentaire' in sans.r.json().lignes[0]).toBe(false);
    const vide = await ajouter('');
    expect('commentaire' in vide.r.json().lignes[0]).toBe(false);
  });
});
