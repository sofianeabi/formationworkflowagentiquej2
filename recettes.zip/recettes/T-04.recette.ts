import { describe, expect, it } from 'vitest';
import { construireApp } from '../../src/app';

const MAINTENANT = new Date('2026-06-15T10:00:00Z');
const alice = { 'x-user-id': 'alice', 'x-role': 'employe' };
const bob = { 'x-user-id': 'bob', 'x-role': 'manager' };
const diane = { 'x-user-id': 'diane', 'x-role': 'directeur' };
const carl = { 'x-user-id': 'carl', 'x-role': 'comptable' };
type H = Record<string, string>;

function ligne(s: Record<string, unknown> = {}) {
  return { date: '2026-06-10', categorie: 'transport', montantHT: 1000, tauxTVA: 20, justificatif: true, libelle: 'Test', ...s };
}
async function noteAvecLignes(app: ReturnType<typeof construireApp>, h: H, lignes: object[], soumettre = false) {
  const { id } = (await app.inject({ method: 'POST', url: '/notes', headers: h })).json();
  for (const l of lignes) {
    const r = await app.inject({ method: 'POST', url: `/notes/${id}/lignes`, headers: h, payload: l });
    if (r.statusCode !== 201) throw new Error(`ligne refusée: ${r.body}`);
  }
  if (soumettre) await app.inject({ method: 'POST', url: `/notes/${id}/soumettre`, headers: h });
  return id as string;
}
const nouvelle = () => construireApp(() => MAINTENANT);

describe('T-04 synthèse', () => {
  it('regroupe par catégorie, triée, avec le TTC', async () => {
    const app = nouvelle();
    const id = await noteAvecLignes(app, alice, [
      ligne({ categorie: 'transport', montantHT: 1000, tauxTVA: 20 }),
      ligne({ categorie: 'repas', montantHT: 1000, tauxTVA: 10 }),
      ligne({ categorie: 'repas', montantHT: 500, tauxTVA: 0 }),
    ]);
    const r = await app.inject({ method: 'GET', url: `/notes/${id}/synthese`, headers: alice });
    expect(r.statusCode).toBe(200);
    expect(r.json()).toEqual({
      noteId: id,
      parCategorie: [
        { categorie: 'repas', nombreLignes: 2, totalTTC: 1600 },
        { categorie: 'transport', nombreLignes: 1, totalTTC: 1200 },
      ],
      totalTTC: 2800,
    });
    const note = await app.inject({ method: 'GET', url: `/notes/${id}`, headers: alice });
    expect(note.json().totalTTC).toBe(2800);
  });
  it('note vide', async () => {
    const app = nouvelle();
    const id = await noteAvecLignes(app, alice, []);
    const r = await app.inject({ method: 'GET', url: `/notes/${id}/synthese`, headers: alice });
    expect(r.json().parCategorie).toEqual([]);
    expect(r.json().totalTTC).toBe(0);
  });
  it("refuse l'accès à un autre employé", async () => {
    const app = nouvelle();
    const id = await noteAvecLignes(app, alice, [ligne()]);
    const r = await app.inject({ method: 'GET', url: `/notes/${id}/synthese`, headers: { 'x-user-id': 'eve', 'x-role': 'employe' } });
    expect(r.statusCode).toBe(403);
  });
});
