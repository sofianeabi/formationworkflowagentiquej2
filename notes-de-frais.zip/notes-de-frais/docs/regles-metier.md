# Règles métier des notes de frais

Source de vérité fonctionnelle. En cas de doute entre le code et ce document, ce document gagne et le code est à corriger.

## Vocabulaire

- **Note de frais** : regroupe les dépenses d'un employé. Elle a un statut.
- **Ligne** : une dépense (date, catégorie, montant HT, taux de TVA, justificatif).
- **Employé, manager, directeur, comptable** : les quatre rôles.

## Montants

- **R1.** Tous les montants sont des entiers en centimes. Jamais de nombre à virgule.
- **R2.** TVA = montant HT × taux / 100, **arrondie au centime le plus proche** (0,5 centime arrondi vers le haut). TTC = HT + TVA.
- **R3.** Taux de TVA autorisés : 0, 5,5, 10, 20.

## Lignes

- **R4.** Plafond TTC par ligne : repas 30,00 €, hôtel 120,00 €, autre 50,00 €. Transport : pas de plafond.
- **R5.** Justificatif obligatoire pour toute ligne dont le TTC est **strictement supérieur** à 25,00 €.
- **R6.** La date d'une ligne ne peut pas être dans le futur.
- **R7.** Une ligne ne peut pas être soumise plus de 60 jours après sa date.

## Cycle de vie

`brouillon` → `soumise` → `approuvee` ou `rejetee` ; `approuvee` → `remboursee`.

- **R8.** Seul le propriétaire modifie son brouillon et le soumet.
- **R9.** Soumission : au moins une ligne, et toutes les lignes respectent R4 à R7.
- **R10.** Approbation par un manager ou un directeur. **Nul ne peut approuver sa propre note, quel que soit son rôle.**
- **R11.** Si le total TTC dépasse **strictement** 500,00 €, seul un directeur peut approuver.
- **R12.** Un rejet exige un motif non vide (les espaces seuls ne comptent pas).
- **R13.** Seul un comptable rembourse, et seulement une note approuvée.
- **R14.** Un employé ne voit que ses notes. Les autres rôles voient toutes les notes.
