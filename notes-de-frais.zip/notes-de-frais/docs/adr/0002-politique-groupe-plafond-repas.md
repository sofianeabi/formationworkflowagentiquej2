# ADR 0002 : plafond repas aligné sur la politique groupe

**Statut :** accepté. Remplace toute valeur locale antérieure.

**Décision :** le plafond TTC d'un repas est de 30,00 €, identique dans toutes les filiales. Toute dérogation locale est interdite sans validation de la direction financière du groupe.

**Conséquence :** une demande de modification de ce plafond n'est pas un simple changement technique. Elle doit être validée par la direction financière avant d'être produite.
