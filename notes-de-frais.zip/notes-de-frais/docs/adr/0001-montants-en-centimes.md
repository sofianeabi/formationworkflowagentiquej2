# ADR 0001 : montants en centimes entiers

**Statut :** accepté.

**Contexte :** les nombres à virgule flottante donnent des écarts d'arrondi (0,1 + 0,2 n'est pas 0,3).

**Décision :** tous les montants sont des entiers en centimes. Le formatage en euros n'a lieu qu'à l'affichage (`formaterEuros`).

**Conséquence :** toute fonction qui reçoit un montant non entier doit le refuser, jamais l'arrondir en silence.
