# Architecture

```
HTTP (Fastify)  src/app.ts       routes, identité par en-têtes x-user-id et x-role
   |
Service         src/service.ts   cycle de vie de la note, droits
   |
Règles          src/rules.ts     plafonds, seuils, délais (fonctions pures)
Argent          src/money.ts     TVA, TTC, formatage (fonctions pures)
Stockage        src/store.ts     en mémoire
```

- Les règles et l'argent sont des **fonctions pures** : c'est là que les tests sont les moins chers et les plus utiles.
- Le service ne contient pas de règle chiffrée : il appelle `rules.ts`.
- Les erreurs métier sont des `ErreurMetier` avec un code stable (`LIGNE_PLAFOND_DEPASSE`, `AUTO_APPROBATION`, ...).

## Commandes

| But | Commande |
|---|---|
| Tests | `npm test` |
| Tests et couverture | `npm run test:cov` |
| Types | `npm run typecheck` |
| Lint | `npm run lint` |
| Toutes les portes | `npm run gates` |
