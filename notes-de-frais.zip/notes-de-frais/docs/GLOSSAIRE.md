# Glossaire

| Terme | Définition |
|---|---|
| Note | Regroupement de lignes de dépense d'un employé |
| Ligne | Une dépense : date, catégorie, HT, taux de TVA, justificatif |
| Plafond | Montant TTC maximal autorisé pour une ligne d'une catégorie |
| Justificatif | Pièce prouvant la dépense, obligatoire au-dessus de 25,00 € TTC |
| Soumettre | Passer une note du brouillon à l'état soumise |
| Approuver | Valider une note soumise (manager ou directeur) |
| Rembourser | Payer une note approuvée (comptable) |
| Porte | Contrôle automatique qui laisse passer ou bloque une production |
