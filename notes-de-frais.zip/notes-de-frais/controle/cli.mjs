#!/usr/bin/env node
// Outillage de la chaîne : contrôle qualité des missions. Ne pas modifier.
import fs from 'node:fs';
import path from 'node:path';
import { auditer, dossierTravail, plageJournal, preparerPoste, reinitialiserPoste } from './lib/audit.mjs';
import { compterTests, lancerPortes, missionN } from './lib/missions.mjs';
import { mutants } from './lib/mutants.mjs';
import {
  RACINE, afficher, existe, git, gras, gris, info, jaune, lancer, rouge, vert,
} from './lib/util.mjs';

const [, , commande, ...reste] = process.argv;
const NOMS = {
  1: 'Fondations', 2: 'Skills', 3: 'Rôles (agents)', 4: 'Portes (hooks)',
  5: 'Ligne de production (T-01)', 6: 'Recette (T-07, T-08, T-09)', 7: 'Plan 30 jours',
};

function mission5() {
  return auditer('T-01');
}

function mission6() {
  const plages = {};
  let tout = [];
  for (const id of ['T-07', 'T-08', 'T-09']) {
    if (id === 'T-09' && !existe(dossierTravail(id))) {
      tout.push(info('09.i', 'T-09 non traité : optionnel (T-07 et T-08 portent les deux leçons).'));
      continue;
    }
    const r = auditer(id).map((x) => ({ ...x, id: `${id.replace('T-', '')}.${x.id.replace('A.', '')}` }));
    tout = tout.concat(r);
    plages[id] = plageJournal(id);
  }
  const ps = Object.values(plages).filter(Boolean);
  if (ps.length >= 2) {
    const debut = Math.max(...ps.map((p) => p[0]));
    const fin = Math.min(...ps.map((p) => p[1]));
    tout.push(info('6.i', debut < fin ? 'Production en parallèle détectée : les postes ont travaillé en même temps.' : 'Les tickets ont été traités l\'un après l\'autre (pas en parallèle).'));
  }
  return tout;
}

function calculer(n) {
  return n === 5 ? mission5() : n === 6 ? mission6() : missionN(n);
}

function doctor() {
  const res = [];
  const major = Number(process.versions.node.split('.')[0]);
  res.push({ id: 'D.1', libelle: `Node ${process.versions.node} (20 minimum)`, ok: major >= 20, conseil: 'Installez Node 20 ou plus.' });
  res.push({ id: 'D.2', libelle: 'Dépendances installées', ok: existe(path.join(RACINE, 'node_modules', 'vitest')), conseil: 'Lancez npm install.' });
  const g = git(['--version']);
  res.push({ id: 'D.3', libelle: 'git disponible', ok: g.code === 0, conseil: 'Installez Git.' });
  const dep = git(['rev-parse', '--is-inside-work-tree']);
  res.push({ id: 'D.4', libelle: 'Le dossier est un dépôt git avec au moins un commit', ok: dep.code === 0 && git(['rev-parse', 'HEAD']).code === 0, conseil: 'git init puis git add . et git commit -m "chore: etat initial".' });
  const c = lancer('claude', ['--version']);
  res.push({ id: 'D.5', libelle: `Claude Code : ${c.code === 0 ? c.stdout.trim() : 'introuvable'}`, ok: c.code === 0, conseil: 'La commande claude doit être dans le PATH.' });
  res.push({ id: 'D.6', libelle: 'Fichier .env présent (leurre de l\'atelier sécurité)', ok: existe(path.join(RACINE, '.env')), conseil: 'Le fichier .env fourni dans le kit a été supprimé.' });
  const n = compterTests();
  res.push({ id: 'D.7', libelle: `Tests verts : ${n ? `${n.total - n.echecs}/${n.total}` : 'non exécutés'}`, ok: Boolean(n) && n.echecs === 0 && n.total > 0, conseil: 'npm test doit passer avant de commencer.' });
  const wt = git(['worktree', 'list']).code === 0;
  res.push({ id: 'D.8', libelle: 'git worktree disponible (production en parallèle)', ok: wt, conseil: 'Mettez git à jour.' });
  return afficher('DIAGNOSTIC DU POSTE', res);
}

async function main() {
  switch (commande) {
    case 'doctor': process.exit(doctor() ? 0 : 1); break;
    case 'gates': {
      console.log(gras('PORTES QUALITÉ'));
      const r = lancerPortes();
      const ok = r.every((x) => x.ok);
      console.log(ok ? vert('\nToutes les portes sont passées.') : rouge('\nUne porte au moins a bloqué.'));
      process.exit(ok ? 0 : 1);
      break;
    }
    case 'check': {
      const n = Number(reste[0]);
      if (!NOMS[n]) { console.error('Usage : npm run controle -- check <1 à 7>'); process.exit(2); }
      const ok = afficher(`MISSION ${n} : ${NOMS[n]}`, calculer(n));
      process.exit(ok ? 0 : 1);
      break;
    }
    case 'worktree': {
      const r = preparerPoste(reste[0]);
      if (!r.ok) { console.error(rouge(r.message)); process.exit(1); }
      console.log(vert(`Poste prêt : ${r.dossier}`));
      console.log(`Ensuite : cd "${r.dossier}" puis claude`);
      break;
    }
    case 'phase': {
      const v = reste[0] === 'aucune' ? '' : reste[0];
      if (!['rouge', 'vert', ''].includes(v)) { console.error('Usage : npm run controle -- phase rouge|vert|aucune'); process.exit(2); }
      fs.mkdirSync(path.join(RACINE, '.workflow'), { recursive: true });
      if (v === '') fs.rmSync(path.join(RACINE, '.workflow', 'phase'), { force: true });
      else fs.writeFileSync(path.join(RACINE, '.workflow', 'phase'), v);
      console.log(`Phase de production : ${v || 'aucune (travail libre)'}`);
      break;
    }
    case 'reset': {
      const r = reinitialiserPoste(reste[0]);
      console.log(r.ok ? vert(`Poste ${reste[0]} supprimé : vous pouvez en créer un neuf.`) : rouge(r.message));
      break;
    }
    case 'audit': {
      const id = reste[0];
      const ok = afficher(`AUDIT ${id}`, auditer(id));
      process.exit(ok ? 0 : 1);
      break;
    }
    case 'mutants': {
      console.log(gras('SOLIDITÉ DES TESTS (mutants)'));
      console.log(gris('Chaque mutant est un bug volontaire. Un bon jeu de tests doit le détecter.\n'));
      const res = mutants();
      let tues = 0; let total = 0;
      for (const m of res) {
        if (m.statut === 'non applicable') { console.log(`  ${gris('-')} ${m.id} ${m.description} (non applicable)`); continue; }
        total += 1;
        if (m.statut === 'tué') { tues += 1; console.log(`  ${vert('✔')} ${m.id} ${m.description}`); }
        else console.log(`  ${rouge('✘')} ${m.id} ${m.description}  ${jaune(`→ survit dans src/${m.fichier}`)}`);
      }
      const pct = total ? Math.round((tues * 100) / total) : 0;
      console.log(`\nScore : ${tues}/${total} bugs détectés (${pct} %). Objectif : 80 % et plus.`);
      process.exit(pct >= 80 ? 0 : 1);
      break;
    }
    case 'score': {
      const lignes = [];
      let reussies = 0;
      const detail = [];
      for (let n = 1; n <= 7; n += 1) {
        const origine = console.log;
        console.log = () => {};
        let ok = false;
        try { ok = calculer(n).filter((r) => !r.info).every((r) => r.ok); } catch { ok = false; }
        console.log = origine;
        lignes.push(`  ${ok ? vert('✔') : rouge('✘')} Mission ${n} : ${NOMS[n]}`);
        if (ok) { reussies += 1; detail.push(`M${n}`); }
      }
      console.log(`\n${gras('TABLEAU DE BORD DE LA CHAÎNE')}`);
      console.log(lignes.join('\n'));
      const nom = reste[0] ?? 'moi';
      console.log(`\nÀ coller dans le chat : ${nom} | ${reussies}/7 | ${detail.join(' ') || 'aucune'}`);
      break;
    }
    default:
      console.log(`Usage : npm run controle -- <commande>
  doctor            diagnostic du poste
  check <1 à 7>     contrôle qualité d'une mission
  score [prénom]    tableau de bord de toutes les missions
  worktree T-xx     prépare un poste de travail isolé pour un ticket
  phase rouge|vert|aucune   fixe la phase de production (lue par la porte de phase)
  reset T-xx        supprime le poste et la branche d'un ticket pour recommencer
  audit T-xx        audit de la production d'un ticket
  mutants           solidité de vos tests
  gates             toutes les portes qualité`);
  }
}

main();
