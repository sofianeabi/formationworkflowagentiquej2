# Carte 0 : règles du jeu

**Poste :** tous · **Durée :** 25 min avec l'ouverture · **À faire :** installer et vérifier le poste

## Le principe

Aujourd'hui vous ne corrigez pas du code : vous construisez **la chaîne qui produit et contrôle le code**. Le chantier est une API de notes de frais. Le vrai livrable de la journée, c'est votre chaîne : des règles, des skills, une équipe d'agents, un workflow écrit, des portes automatiques, un tracker branché par MCP, un plan pour l'installer chez vous.

| Artisan | Chaîne contrôlée |
|---|---|
| Je lis, je corrige, j'espère | Une porte automatique décide si ça passe |
| Mon code est bon car je l'ai relu | Mon code est bon car la preuve est rejouable |
| Je corrige le produit | Je corrige le processus qui l'a mal produit |
| La qualité dépend de ma vigilance | La qualité est dans la chaîne |

## Comment fonctionnent les cartes

Chaque carte est un **ordre de mission** : un objectif, un livrable, un cahier des charges et un contrôle. Elle dit **quoi** produire et **comment on le vérifiera**, jamais le contenu à écrire : c'est vous qui concevez, avec Claude Code comme outil.

1. Lisez la carte en entier (2 minutes).
2. Produisez le livrable. Claude écrit, **vous décidez et vous vérifiez**.
3. Lancez le contrôle de la carte : `npm run controle -- check <n>`.
4. Si une ligne est rouge, lisez le conseil, corrigez, relancez. Le contrôle est votre juge, pas le formateur.
5. Quand c'est vert, collez votre score dans le chat et passez à la carte suivante.

## Mise en route (5 minutes)

Utilisez **Git Bash** (installé avec Git for Windows) ou PowerShell 7 : les commandes des cartes, avec `&&`, supposent l'un des deux. Claude Code doit être à jour (`claude update`).

```bash
cd notes-de-frais
npm install
npm run controle -- doctor
```

Les 8 lignes du diagnostic doivent être vertes. Sinon, écrivez dans le chat avec la ligne en rouge.

## Le tableau de bord

```bash
npm run controle -- score votre-prenom
```

Une ligne à coller dans le chat : le formateur voit où en est chacun sans rien demander. Elle rejoue les 7 contrôles, donc plusieurs minutes : lancez-la en fin de carte, pas pendant.

## Règles de sécurité du jeu

- Ne lisez jamais le dossier `controle/recettes/` et interdisez-le à votre IA : ce sont les étalons du contrôle final. Le formateur vous les remet à 15 h (`recettes.zip`) : vous les décompressez sans les ouvrir.
- Ne modifiez pas `controle/`.
- Jamais de mode « bypass permissions ». Une chaîne sérieuse n'arrête pas ses portes pour aller plus vite.
- Aucun `git push` : tout reste sur votre poste.

## Rythme de la journée

| Heure | Carte |
|---|---|
| 9 h 00 | Ouverture et mise en route |
| 9 h 25 | Carte 1 : fondations |
| 10 h 40 | Carte 2 : skills et tracker (après la pause de 10 h 25) |
| 13 h 30 | Carte 3 : rôles et workflow |
| 11 h 50 | Débrief du matin |
| 14 h 15 | Carte 4 : portes |
| 15 h 00 | Carte 5 : ligne de production (après la pause de 14 h 50) |
| 15 h 50 | Carte 6 : recette |
| 16 h 20 | Débrief de la production |
| 16 h 30 | Carte 7 : plan 30 jours |
