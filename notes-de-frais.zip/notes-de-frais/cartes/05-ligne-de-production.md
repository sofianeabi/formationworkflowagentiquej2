# Carte 5 : ligne de production

**Poste :** premier ticket de bout en bout · **Début :** 15 h 00 · **Durée :** 50 min · **Contrôle :** `npm run controle -- check 5`

## Objectif

Faire tourner **votre** chaîne sur le ticket `T-01` (catégorie péage), sans toucher au code vous-même, puis la faire auditer. La ligne lit le ticket et rend compte dans le tracker branché à la carte 2.

## Livrable

Une branche `ticket/T-01` produite par votre ligne : spec, tests rouges, code vert, relecture, portes vertes.

## Déroulé

1. Le formateur poste `recettes.zip` dans le chat : décompressez-le **dans le dossier `controle/`** (il crée `controle/recettes/`) et ne l'ouvrez pas. Puis **commitez votre chaîne** (y compris `.mcp.json` et `.claude/workflow.md`) sur `main` : `git add .claude CLAUDE.md docs && git commit -m "chore: workflow"`. Ajoutez d'abord `.claude/settings.local.json` à votre `.gitignore` s'il manque. Un poste de travail n'existe que sur ce qui est commité.
2. Créez le poste isolé : `npm run controle -- worktree T-01`.
3. Placez-vous dedans (`cd ../wt-T-01`) et lancez : `claude --agent coordinateur`. Acceptez la confiance du dossier si elle vous est demandée : sans cela, vos règles `permissions.allow` sont ignorées (si Claude demande des autorisations déjà écrites chez vous, c'est la cause).
4. Donnez-lui une seule phrase : « Traite le ticket T-01. »
5. **Regardez** le journal grossir (`.workflow/journal.jsonl`) sans intervenir.
6. Quand il a fini : `npm run controle -- check 5` depuis le dossier d'origine.

## Ce que l'audit vérifie

| Contrôle | Ce qu'il prouve |
|---|---|
| Spec en 5 champs | on a spécifié avant de produire |
| Commit de tests avant commit de code | le rouge a précédé le vert |
| Aucun test existant modifié | on n'a pas arrangé les tests pour passer |
| Rien hors de `src/ tests/ specs/ docs/` | le périmètre est tenu |
| 2 corrections au plus | la chaîne sait s'arrêter |
| Portes qualité vertes | types, lint, tests, couverture |
| **Recette indépendante** | des tests d'acceptation que vous n'avez jamais vus passent sur votre code |
| Messages de commit `type: description` | l'historique est lisible et auditable |
| Tout est commité dans le poste | rien ne traîne hors de l'historique |
| Journal présent | la production est traçable |
| **Tracker** : statut final et commentaire de trace | le ticket est passé en `pret-a-relire` (ou `ready-for-human`) avec chaque critère relié à un test qui existe (règle 7) |

## Si l'audit est rouge : la règle d'or

**On ne corrige pas le produit, on corrige la chaîne.** Si la spec est incomplète, c'est le skill `spec` ou l'agent `analyste` qui est à améliorer. Si un test existant a été modifié, c'est une porte qui manquait. Puis :

```bash
npm run controle -- reset T-01        # supprime le poste et la branche
git add .claude CLAUDE.md docs && git commit -m "chore: v2"
npm run controle -- worktree T-01     # nouveau poste, chaîne corrigée
```

Relancez. **Règle du temps :** un passage complet prend 10 à 20 minutes. Si le premier audit est rouge, lisez les causes, notez-les, et faites **un seul** reset au plus tard à **15 h 30**. Passé cette heure, gardez le résultat tel quel et passez à la carte 6. Les statuts du tracker sont propres à chaque poste (`.workflow/tracker.json`). Un ticket réussi du premier coup avec une chaîne fragile ne prouve rien ; un ticket réussi après une correction **de la chaîne** prouve quelque chose.

## Points de vigilance

- Ne rédigez pas le code à la place de l'équipe : si vous intervenez, l'audit ne mesure plus votre chaîne.
- Si l'IA bloque sur des autorisations, c'est que vos `permissions.allow` sont incomplètes : ajoutez-y la commande précise, pas un `Bash` en bloc.
- Notez ce qui vous surprend : c'est la matière du débrief.
- Si votre auditeur ou votre relecteur remonte un défaut **déjà présent** dans le code (par exemple l'arrondi de la TVA) et que la ligne rend la main avec `ready-for-human`, ce n'est pas un échec : c'est la chaîne qui fait son travail.

## Si vous avez fini en avance

Traitez `T-02` (bug de TVA) et `T-03` (auto-approbation du directeur). Un bug se traite comme une fonctionnalité : d'abord un test qui échoue. Passez ensuite la liste du backlog avec `lister_tickets` : que ferait un niveau d'autonomie 4 (planifié) avec elle ? Ou faites tenir au coordinateur un **journal de décisions** (hash du commit rouge, verdict de chaque agent).
