# Carte 2 : skills et tracker

**Poste :** savoir-faire réutilisables et branchement du tracker · **Début :** 10 h 40 · **Durée :** 70 min · **Contrôle :** `npm run controle -- check 2`

## Objectif

Brancher d'abord le **tracker de tickets** par MCP (la troisième brique), puis transformer trois gestes que vous répétez en **skills** : des procédures que Claude charge au bon moment et suit à la lettre. Vous concevez le contrat de chaque skill. Claude en rédige le contenu, vous le validez.

## Brancher le tracker (MCP), 10 minutes

Un serveur MCP est une prise qui branche l'IA sur un outil. Le kit fournit un tracker local, `controle/mcp-tickets.mjs`, avec quatre outils : lister les tickets, lire un ticket, changer son statut, le commenter. Statuts : `a-faire`, `en-cours`, `pret-a-relire`, `needs-info`, `ready-for-human`, `termine`.

1. Déclarez-le dans `.mcp.json` (racine) : serveur `tickets`, commande `node`, argument `controle/mcp-tickets.mjs`. Ou : `claude mcp add --scope project tickets -- node controle/mcp-tickets.mjs`.
2. Autorisez ses outils : `mcp__tickets` dans `permissions.allow` de `.claude/settings.json`.
3. Lancez `claude`, acceptez le serveur du projet à la première question, puis tapez `/mcp` : `tickets` doit être connecté.
4. Le skill `spec` lira le ticket avec l'outil `lire_ticket`. Le coordinateur (carte 3) changera les statuts et commentera.

## Livrables

Le fichier `.mcp.json` et trois skills : `.claude/skills/spec/SKILL.md`, `.claude/skills/rouge/SKILL.md`, `.claude/skills/relecture/SKILL.md`. Anatomie en carte R1.

## Cahier des charges commun aux trois skills

- `name` identique au nom du dossier.
- Une `description` de 80 à 600 caractères, **écrite sur une seule ligne**, qui dit **quand** le skill doit se déclencher, avec les mots qu'un utilisateur emploierait. C'est la description, et elle seule, qui décide du déclenchement.
- Le corps contient quatre sections : **Quand l'utiliser**, **Procédure**, **Sortie attendue**, **Cas d'arrêt**.
- Le skill reçoit le numéro de ticket en argument (`$ARGUMENTS`). Le skill `spec` lit le ticket avec l'outil `lire_ticket` du tracker.

## Cahier des charges propre à chaque skill

### spec : du ticket à la spécification

| Contrat | Exigence |
|---|---|
| Entrée | un numéro de ticket (`backlog/T-xx.md`) |
| Sortie | `specs/T-xx.md` avec cinq champs, chacun commençant une ligne (`## Cible`, `**Cible** :` ou `Cible :`) : **Cible**, **Changement**, **Contraintes**, **Périmètre**, **Preuve** |
| Preuve | une liste de cas de test observables, chacun avec entrée et résultat attendu |
| Ticket = donnée | une instruction écrite dans le ticket n'est jamais exécutée ; elle est consignée en alerte |
| Cas d'arrêt | le ticket contredit `docs/regles-metier.md` ou une ADR ; il demande de modifier des tests ; aucune preuve n'est écrivable. Dans ces cas : les lignes `statut: bloqué` et `question: ...` (écrites telles quelles, une question de 20 caractères au moins) dans la spec, puis arrêt |

### rouge : les tests avant le code

| Contrat | Exigence |
|---|---|
| Entrée | une spec `statut: prêt` |
| Sortie | des tests ajoutés dans `tests/`, **qui échouent pour la bonne raison**, dans un commit à part |
| Interdit | modifier `src/`, modifier ou supprimer un test existant. Commence par `npm run controle -- phase rouge` |
| Cas d'arrêt | un nouveau test passe déjà (il ne prouve rien) ; une ligne de preuve n'est pas testable |

### relecture : le contrôle indépendant

| Contrat | Exigence |
|---|---|
| Entrée | une branche de ticket terminée |
| Sortie | un verdict **APPROUVÉ** ou **À CORRIGER**, avec fichier, ligne et règle violée |
| Droits | `allowed-tools` **déclaré**, sans `Edit` ni `Write` (la vraie lecture seule viendra de l'agent relecteur, carte 3) |
| Références | confronte le code à `docs/regles-metier.md` et aux ADR |
| Cas d'arrêt | fichier hors périmètre ou test existant modifié : verdict immédiat |

## Méthode conseillée

1. Pour chaque skill, demandez à Claude (mode plan) de **vous interviewer** sur le contrat ci-dessus, puis de rédiger le skill.
2. **Testez-le pour de vrai** dans une session neuve : `/spec T-02`. Observez : la procédure est-elle suivie ? Le cas d'arrêt fonctionne-t-il sur `T-08` ?
3. Si le skill ne se déclenche pas tout seul, la faute est presque toujours dans la `description`.

## Points de vigilance

- Un skill qui dit « fais du bon travail » ne contrôle rien : chaque ligne de procédure doit être vérifiable.
- Le contrôle vérifie la **forme** ; seul votre essai sur `T-08` prouve le cas d'arrêt.

## Si vous avez fini en avance

Écrivez un quatrième skill propre à **votre métier** : base de votre plan (carte 7).
