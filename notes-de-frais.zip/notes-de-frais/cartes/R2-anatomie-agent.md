# Aide-mémoire R2 : anatomie d'un agent

Un agent (sous-agent) est un fichier Markdown : `.claude/agents/<nom>.md`.

```markdown
---
name: nom-de-l-agent
description: Quand déléguer à cet agent, en une ou deux phrases.
tools: Read, Grep, Glob, Bash
model: sonnet
skills:
  - nom-du-skill
---

Consigne de l'agent : son rôle, ce qu'il rend, ce qu'il lui est interdit de faire.
```

| Champ | Rôle |
|---|---|
| `name` | identifiant (égal au nom du fichier) |
| `description` | utilisée par le coordinateur pour décider de déléguer (sur une seule ligne) |
| `tools` | liste des outils autorisés. **Sans cette liste, l'agent hérite de tout**. Les outils d'un serveur MCP : `mcp__tickets__*` |
| `disallowedTools` | liste de refus, appliquée avant `tools` |
| `model` | `sonnet`, `opus`, `haiku`, `fable` ou `inherit` |
| `skills` | skills chargés dans le contexte de l'agent au démarrage |

**Pour lancer une session dont le fil principal est un agent :** `claude --agent coordinateur`. Pour qu'il puisse déléguer, son `tools` contient `Agent`.

**Ce qui compte :** un agent travaille dans son **propre contexte**. Il rend un rapport, pas toute sa conversation. C'est ce qui permet de garder un coordinateur léger et des ouvriers concentrés.

**Modèles :** le plus fort pour décider et vérifier (coordinateur), un modèle intermédiaire pour exécuter (ouvriers). Le coût et la vitesse suivent.
