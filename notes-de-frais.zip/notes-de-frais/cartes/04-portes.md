# Carte 4 : portes

**Poste :** contrôles automatiques · **Début :** 14 h 15 · **Durée :** 35 min · **Contrôle :** `npm run controle -- check 4`

## Objectif

Transformer vos règles en **barrières que même l'IA ne peut pas franchir**. Un hook est un petit programme que Claude Code exécute avant ou après chaque outil. S'il répond « non », l'action est bloquée.

## Livrables

Trois scripts Node dans `.claude/hooks/` et leur déclaration dans `.claude/settings.json` (bloc `hooks`), plus un workflow GitHub Actions `.github/workflows/ci.yml`. Anatomie des hooks en carte R3.

## Les quatre portes

### Porte 1 : la phase

Un fichier `.workflow/phase` contient la phase en cours (`rouge`, `vert`, ou rien). Les agents la fixent avec `npm run controle -- phase rouge` (ou `vert`, ou `aucune`) : la commande est fournie, c'est **votre porte** qui la lit. Elle refuse les écritures selon la phase :

| Phase | Écrire dans `src/` | Écrire dans `tests/` |
|---|---|---|
| `rouge` | refusé | autorisé |
| `vert` | autorisé | refusé |
| aucune | autorisé | autorisé |

- Elle s'applique aux outils d'écriture (`Edit`, `Write`, `MultiEdit`).
- Elle doit marcher avec un chemin **Windows** (barres inverses `C:\...\src\rules.ts`).
- Elle écrit sa raison sur **stderr** et termine avec le code **2**.

### Porte 2 : les secrets et les gestes dangereux

Refuse, quel que soit l'outil : la lecture de `.env`, une commande Bash qui le touche (`cat .env`), `git push` (surtout `--force`). Mais **laisse passer** `npm test` : une porte qui bloque tout est une porte qu'on retire.

### Porte 3 : le journal

Chaque action ajoute une ligne JSON à `.workflow/journal.jsonl` avec au minimum : l'horodatage `ts`, l'outil `tool`, la cible. Ce journal servira à **auditer** la production après coup (cartes 5 et 6).

### Porte 4 : la CI (GitHub Actions)

Les trois premières portes protègent **votre poste**. La CI est la porte qui ne dépend pas de votre poste : un serveur rejoue `npm run gates` sur chaque demande de fusion, et la fusion est refusée si elle échoue. C'est le prérequis du niveau d'autonomie 3 (carte 3).

- Fichier `.github/workflows/ci.yml`, déclenché sur `pull_request` (et sur `push` vers `main`).
- Un job sur `ubuntu-latest` : `actions/checkout`, `actions/setup-node` (Node 20 ou plus), `npm ci`, puis `npm run gates`.
- Aucune échappatoire : ni `continue-on-error: true`, ni `|| true`, qui rendraient la porte inoffensive.
- Claude l'écrit en quelques minutes ; vous vérifiez chaque ligne. Ici, personne ne la pousse (pas de dépôt distant) : le contrôle lit le fichier. Chez vous, vous l'activerez avec une règle de protection de branche qui exige ce job.

## Cahier des charges technique

- Écrits en **Node** (`.mjs`) : ils marchent à l'identique sous Windows, macOS et Linux.
- Déclarés **obligatoirement** en forme `{ "command": "node", "args": [chemin] }` (carte R3). La forme en simple chaîne n'est pas portable.
- Pour retrouver la racine du poste, lisez `CLAUDE_PROJECT_DIR` (variable d'environnement) plutôt que `cwd` : `cwd` change quand Claude fait un `cd`.
- Le champ `ts` du journal est une date ISO 8601 (`new Date().toISOString()`).
- Lisent l'entrée JSON sur l'entrée standard (outil, chemin ou commande, répertoire courant).
- Déclarés dans `hooks.PreToolUse` avec un `matcher` adapté aux outils concernés.
- Le journal ne doit jamais faire échouer une action : il termine toujours avec le code 0.

## Méthode conseillée

1. Faites écrire un hook à Claude, **puis testez-le à la main** avant de l'enregistrer :
   Dans Git Bash :
   ```bash
   echo '{"tool_name":"Edit","tool_input":{"file_path":"src/rules.ts"},"cwd":"."}' | node .claude/hooks/phase-guard.mjs; echo "code: $?"
   ```
2. Le contrôle `check 4` rejoue **16 contrôles** contre vos hooks réels et votre CI : il vous dit lequel échoue. Procédez comme en test-driven development : un scénario rouge, vous corrigez, vous relancez.
3. Vérifiez dans Claude Code que la porte fonctionne **en vrai** : mettez `rouge` dans `.workflow/phase` et demandez-lui de modifier `src/money.ts`.

## Points de vigilance

- Les crochets protègent des outils `Edit` et `Write`, pas de tout : un `echo > fichier` dans Bash les contourne. Une porte seule ne suffit pas : c'est pourquoi la carte 5 ajoute un **audit après coup**.
- Un faux positif coûte cher : testez qu'un `npm test` reste autorisé.
- Pendant une production, la chaîne elle-même (`.claude/`, `controle/`, `package.json`) devrait être verrouillée en écriture. `check 4` ne le teste pas, mais l'audit de la carte 5 le rattrape : un fichier hors `src/ tests/ specs/ docs/` fait échouer le périmètre.

## Si vous avez fini en avance

Ajoutez une porte qui refuse de commiter si `npm run gates` ne passe pas, ou ajoutez à la CI une étape qui lance `npm run controle -- mutants`.
