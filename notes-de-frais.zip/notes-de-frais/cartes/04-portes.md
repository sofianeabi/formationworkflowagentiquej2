# Carte 4 : portes

**Poste :** contrôles automatiques · **Début :** 14 h 15 · **Durée :** 35 min · **Contrôle :** `npm run controle -- check 4`

## Objectif

Transformer vos règles en **barrières que même l'IA ne peut pas franchir**. Un hook est un petit programme que Claude Code exécute avant ou après chaque outil. S'il répond « non », l'action est bloquée.

## Livrables

Trois scripts Node dans `.claude/hooks/` et leur déclaration dans `.claude/settings.json` (bloc `hooks`), plus un workflow GitHub Actions `.github/workflows/ci.yml` (trois exercices, dont un sur votre propre dépôt GitHub). Anatomie des hooks en carte R3.

## Les quatre portes

### Porte 1 : la phase

Un fichier `.workflow/phase` contient la phase en cours (`rouge`, `vert`, ou rien). Les agents la fixent avec `npm run controle -- phase rouge` (ou `vert`, ou `aucune`) : la commande est fournie, c'est **votre porte** qui la lit. Elle refuse les écritures selon la phase :

| Phase | Écrire dans `src/` | Écrire dans `tests/` |
|---|---|---|
| `rouge` | refusé | autorisé |
| `vert` | autorisé | refusé |
| aucune | autorisé | autorisé |

- Elle s'applique aux outils d'écriture (`Edit`, `Write`, `MultiEdit`).
- Elle doit marcher avec un chemin **Windows** (barres inverses `C:\...\src\rules.ts`).
- Elle écrit sa raison sur **stderr** et termine avec le code **2**.

### Porte 2 : les secrets et les gestes dangereux

Refuse, quel que soit l'outil : la lecture de `.env`, une commande Bash qui le touche (`cat .env`), `git push` (surtout `--force`). Mais **laisse passer** `npm test` : une porte qui bloque tout est une porte qu'on retire.

### Porte 3 : le journal

Chaque action ajoute une ligne JSON à `.workflow/journal.jsonl` avec au minimum : l'horodatage `ts`, l'outil `tool`, la cible. Ce journal servira à **auditer** la production après coup (cartes 5 et 6).

### Porte 4 : la CI (GitHub Actions)

Les trois premières portes protègent **votre poste**. La CI est la porte qui ne dépend pas de votre poste : un serveur rejoue `npm run gates` sur chaque demande de fusion, et la fusion est refusée si elle échoue. C'est le prérequis du niveau d'autonomie 3 (carte 3). Fichier : `.github/workflows/ci.yml`. Trois exercices, dans l'ordre.

**Exercice CI 1 : écrire la CI** (contrôles 4.13 à 4.16)

- Déclencheur : `pull_request`, et `push` vers `main`.
- Un job sur `ubuntu-latest` : `actions/checkout`, `actions/setup-node` (Node 20 ou plus), `npm ci`, puis `npm run gates`.
- Aucune échappatoire : ni `continue-on-error: true`, ni `|| true`, qui rendraient la porte inoffensive.

**Exercice CI 2 : durcir la CI** (contrôles 4.17 et 4.18)

- Droits minimaux : un bloc `permissions:` avec `contents: read`. Une porte de contrôle lit le code, elle n'a pas besoin d'écrire.
- Un job borné : `timeout-minutes` sur le job, pour qu'un blocage ne tourne pas indéfiniment.
- Un cache npm : `cache: npm` dans `setup-node`.
- Demandez à Claude **pourquoi** chaque ligne est là, et refusez celles dont il ne sait pas justifier la présence.

**Exercice CI 3 : la faire tourner pour de vrai sur votre propre dépôt GitHub** (pas de contrôle automatique ; à faire dès que le contrôle 4 est vert, même après 14 h 50, ou pendant que votre ligne tourne à la carte 5)

La CI ne prouve rien tant qu'elle n'a jamais tourné. Vous allez l'exécuter sur un dépôt **à vous**, sans toucher à votre dossier de travail :

1. Commitez votre CI : `git add .github && git commit -m "ci: portes sur pull_request"`.
2. Faites une copie de travail : `git clone . ../notes-de-frais-ci`, puis `cd ../notes-de-frais-ci` et `git remote remove origin`.
3. Créez un dépôt **privé et vide** sur votre compte GitHub personnel ou de test (jamais celui de votre entreprise sans accord). Avec la CLI : `gh repo create notes-de-frais-ci --private --source=. --remote=origin`, ou sur le site puis `git remote add origin <url>`. Poussez **vous-même** : `git push -u origin main`. C'est le seul `git push` de la journée : la règle de sécurité vise la chaîne, pas vous, et seulement vers ce dépôt.
4. Ouvrez l'onglet **Actions** du dépôt : le job `portes` doit être vert. Sinon, lisez le journal du job : l'erreur est la preuve.
5. Preuve que la porte bloque : `git switch -c essai-ci`, cassez volontairement un test (changez un résultat attendu), commitez, poussez la branche, ouvrez une **pull request**. Le job doit être **rouge** et la PR signale l'échec. Corrigez, poussez : il repasse au vert. Une CI qui ne peut pas échouer ne prouve rien.
6. Rendez-la obligatoire : dans les paramètres du dépôt (règles de branche ou *rulesets*), exigez le job `portes` avant toute fusion dans `main` (selon votre offre GitHub, cette option peut être réservée aux dépôts publics ou payants : notez alors ce qu'il vous manque).
7. Écrivez dans le chat une phrase : ce que votre CI aurait attrapé, chez vous, la semaine dernière.

**Sans compte GitHub, ou si le temps manque :** rejouez la CI en local sur une branche jetable : `npm ci` puis `npm run gates` (tout doit être vert), cassez un test, relancez (la porte doit être rouge), puis `git checkout -- tests`.

Supprimez le dépôt de test en fin de journée. Il ne contient que le chantier fictif, jamais votre `.env` (ignoré par git) ni les étalons du formateur.

## Cahier des charges technique

- Écrits en **Node** (`.mjs`) : ils marchent à l'identique sous Windows, macOS et Linux.
- Déclarés **obligatoirement** en forme `{ "command": "node", "args": [chemin] }` (carte R3). La forme en simple chaîne n'est pas portable.
- Pour retrouver la racine du poste, lisez `CLAUDE_PROJECT_DIR` (variable d'environnement) plutôt que `cwd` : `cwd` change quand Claude fait un `cd`.
- Le champ `ts` du journal est une date ISO 8601 (`new Date().toISOString()`).
- Lisent l'entrée JSON sur l'entrée standard (outil, chemin ou commande, répertoire courant).
- Déclarés dans `hooks.PreToolUse` avec un `matcher` adapté aux outils concernés.
- Le journal ne doit jamais faire échouer une action : il termine toujours avec le code 0.

## Méthode conseillée

1. Faites écrire un hook à Claude, **puis testez-le à la main** avant de l'enregistrer :
   Dans Git Bash :
   ```bash
   echo '{"tool_name":"Edit","tool_input":{"file_path":"src/rules.ts"},"cwd":"."}' | node .claude/hooks/phase-guard.mjs; echo "code: $?"
   ```
2. Le contrôle `check 4` rejoue **18 contrôles** contre vos hooks réels et votre CI : il vous dit lequel échoue. Procédez comme en test-driven development : un scénario rouge, vous corrigez, vous relancez.
3. Vérifiez dans Claude Code que la porte fonctionne **en vrai** : mettez `rouge` dans `.workflow/phase` et demandez-lui de modifier `src/money.ts`.

## Points de vigilance

- Les crochets protègent des outils `Edit` et `Write`, pas de tout : un `echo > fichier` dans Bash les contourne. Une porte seule ne suffit pas : c'est pourquoi la carte 5 ajoute un **audit après coup**.
- Un faux positif coûte cher : testez qu'un `npm test` reste autorisé.
- Pendant une production, la chaîne elle-même (`.claude/`, `controle/`, `package.json`) devrait être verrouillée en écriture. `check 4` ne le teste pas, mais l'audit de la carte 5 le rattrape : un fichier hors `src/ tests/ specs/ docs/` fait échouer le périmètre.

## Si vous avez fini en avance

Ajoutez une porte qui refuse de commiter si `npm run gates` ne passe pas, ou ajoutez à la CI une étape qui lance `npm run controle -- mutants`.
