# Aide-mémoire R3 : anatomie d'un hook

Un hook est une commande que Claude Code lance à un moment précis. Il est déclaré dans `.claude/settings.json`.

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Edit|Write",
        "hooks": [
          {
            "type": "command",
            "command": "node",
            "args": ["${CLAUDE_PROJECT_DIR}/.claude/hooks/ma-porte.mjs"]
          }
        ]
      }
    ]
  }
}
```

| Élément | Rôle |
|---|---|
| `PreToolUse` | avant l'outil (peut bloquer). `PostToolUse` : après (ne peut plus bloquer) |
| `matcher` | noms d'outils séparés par `|` (`Edit|Write`), ou `*` pour tous |
| `command` + `args` | forme recommandée : marche sur Windows, macOS, Linux |
| `${CLAUDE_PROJECT_DIR}` | racine du projet |

## Ce que reçoit le script (entrée standard, JSON)

```json
{
  "cwd": "/chemin/du/poste",
  "hook_event_name": "PreToolUse",
  "tool_name": "Edit",
  "tool_input": { "file_path": "/chemin/src/rules.ts" },
  "agent_type": "ouvrier-vert"
}
```

Pour `Bash`, `tool_input.command` contient la commande. `agent_type` n'existe que dans un sous-agent.

## Ce que le script répond

| Code de sortie | Effet |
|---|---|
| `0` | tout va bien, l'action continue |
| `2` | **action bloquée**, le texte écrit sur **stderr** est renvoyé à Claude |
| autre | erreur non bloquante |

Squelette Node :

```js
import fs from 'node:fs';
const entree = JSON.parse(fs.readFileSync(0, 'utf8'));
const racine = process.env.CLAUDE_PROJECT_DIR || entree.cwd;   // cwd change si Claude fait un cd
const chemin = String(entree.tool_input?.file_path ?? '').replaceAll('\\', '/');
if (/(^|\/)src\//.test(chemin)) {
  process.stderr.write('Interdit en phase rouge.\n');
  process.exit(2);
}
process.exit(0);
```

**Pièges :** pas de forme en simple chaîne (`"command": "node script.mjs"`) : utilisez `command` + `args` ; les chemins Windows ont des barres inverses (`replaceAll`) ; un hook qui plante ne bloque rien (code autre que 2) ; ne testez pas à l'aveugle, rejouez à la main avec `echo '{...}' | node script.mjs`.
