# Carte 1 : fondations

**Poste :** état des lieux et règles du site · **Début :** 9 h 25 · **Durée :** 55 min · **Contrôle :** `npm run controle -- check 1`

## Objectif

Rendre le chantier lisible pour une IA **et** pour une porte automatique : un état des lieux factuel, des règles du site courtes, une première enceinte de sécurité.

## Livrables

1. `docs/etat-des-lieux.md`
2. `CLAUDE.md` (à la racine)
3. `.claude/settings.json`
4. `npm run gates` au vert

## Cahier des charges

### 1. docs/etat-des-lieux.md

- Cinq sections : **Commandes**, **Architecture**, **Règles métier**, **Zones à risque**, **Trous de test**.
- Au moins 6 fichiers réels cités entre accents graves (`src/rules.ts`). Chaque chemin cité doit exister.
- Le **vrai nombre de tests** (lancez `npm test` vous-même) est écrit dans le document.
- Les zones à risque et les trous de test sont des constats **vérifiés**, pas des suppositions : pour chacun, vous pouvez montrer la ligne de code ou le test absent.

### 2. CLAUDE.md

- 120 lignes au plus. Chaque ligne doit changer le comportement de l'IA, sinon elle est supprimée.
- Sections **Commandes**, **Conventions**, **Interdits**.
- Les quatre commandes essentielles : `npm test`, `npm run typecheck`, `npm run lint`, `npm run gates`. Toute commande citée doit exister dans `package.json`.
- Renvoie vers `docs/regles-metier.md` au lieu de recopier les règles chiffrées : aucun montant en euros ne doit apparaître dans `CLAUDE.md` (il existerait en double et finirait par diverger).
- Les conventions fixent le format des commits (`type: description`, avec un type parmi `test`, `feat`, `fix`, `docs`, `chore`, `refactor`, `spec`) et le nom des branches (`ticket/T-xx`).

### 3. .claude/settings.json

- Un bloc `permissions` avec `allow` (commandes précises) et `deny`. Pensez à `Bash(git add *)` et `Bash(git commit *)` : la ligne de production devra commiter.
- `deny` doit refuser : la lecture de `.env`, `git push`, la lecture de `controle/recettes/`.
- Aucun `Bash` autorisé en bloc, aucun mode « bypass ».

### 4. Les portes

`npm run gates` doit passer : types, lint, tests, couverture.

## Méthode conseillée

1. Lancez Claude Code dans le dossier du projet, passez en **mode plan** (`Maj+Tab`) et demandez l'exploration du chantier. Le mode plan lit sans modifier.
2. **Vérifiez chaque affirmation** avant de la garder : l'IA invente volontiers un chiffre ou un fichier.
3. Faites rédiger `CLAUDE.md`, puis **coupez** : demandez-vous pour chaque ligne « est-ce que l'IA ferait autrement sans elle ? ».
4. Pour les permissions, laissez Claude proposer, mais c'est **vous** qui décidez de ce qui est interdit.

## Points de vigilance

- Un état des lieux plein de généralités passe le contrôle de forme mais ne sert à rien : visez des constats précis.
- Un `CLAUDE.md` de 300 lignes est moins bien suivi qu'un de 40.
- Un `deny` écrit au mauvais format ne protège de rien : consultez la carte R4. Vérifiez avec `/permissions`.

## Si vous avez fini en avance

Lancez `npm run controle -- mutants` et regardez le score de départ. Notez-le : vous le retrouverez en bonus.
