# Aide-mémoire R1 : anatomie d'un skill

Un skill est un dossier avec un fichier `SKILL.md`.

```
.claude/skills/<nom>/SKILL.md
```

```markdown
---
name: nom-du-skill
description: Ce que fait le skill ET quand l'utiliser, avec les mots que l'utilisateur emploierait.
argument-hint: T-xx
allowed-tools: Read Grep Glob
---

# Titre

## Quand l'utiliser
## Procédure
## Sortie attendue
## Cas d'arrêt
```

| Champ | Rôle |
|---|---|
| `name` | identifiant, égal au nom du dossier ; appelle le skill par `/nom` |
| `description` | **la seule chose que Claude lit pour décider de charger le skill** : soignez-la, sur une seule ligne |
| `argument-hint` | aide affichée à l'utilisateur |
| `allowed-tools` | outils autorisés **sans demander** pendant le skill (liste séparée par des espaces). Cela n'interdit pas les autres : pour retirer des outils, utilisez `tools` d'un agent |
| `disable-model-invocation` | `true` : seul l'utilisateur peut lancer le skill |

Dans le corps, `$ARGUMENTS` est remplacé par ce que vous tapez après `/nom` (`/spec T-02` donne `T-02`).

**Règles d'un bon skill :** une procédure en étapes courtes et vérifiables, une sortie nommée, un cas d'arrêt explicite. Le détail se met dans des fichiers à côté (`SKILL.md` renvoie vers eux) pour ne pas alourdir le contexte.
