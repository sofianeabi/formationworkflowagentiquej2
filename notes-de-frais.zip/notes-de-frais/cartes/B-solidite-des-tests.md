# Carte B (bonus) : la solidité des tests

**Poste :** contrôle qualité des tests · **Durée :** libre · **Contrôle :** `npm run controle -- mutants`

## Objectif

Votre couverture affiche environ 90 %. Pourtant la plupart des bugs volontairement introduits passent inaperçus. La couverture mesure ce qui est **exécuté**, pas ce qui est **vérifié**.

## Le principe du test de mutants

Le contrôle introduit un à un 16 bugs dans le code (un `>` devient `>=`, un plafond change de valeur...) et relance vos tests. Un bug détecté est **tué**. Un bug qui passe inaperçu **survit** : il indique un test manquant.

## Mission

1. Lancez `npm run controle -- mutants`. Notez le score de départ.
2. Pour chaque survivant, écrivez le ticket en une phrase (« Les valeurs limites du plafond ne sont pas testées »).
3. Passez ces tickets dans **votre ligne** : tests d'abord, sans toucher à `src/`.
4. Relancez les mutants. Objectif : **80 %** ou plus.

## Ce qu'il faut en retenir

Une chaîne qui accepte des tests écrits par l'IA doit mesurer leur solidité. Sans cette mesure, « 90 % de couverture » est un chiffre qui rassure sans rien garantir.
