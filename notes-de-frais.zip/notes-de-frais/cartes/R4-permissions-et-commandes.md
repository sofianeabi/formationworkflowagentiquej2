# Aide-mémoire R4 : permissions et commandes

## Permissions (`.claude/settings.json`)

```json
{
  "permissions": {
    "allow": ["Bash(npm test)", "Bash(npm run *)", "Bash(git commit *)"],
    "deny":  ["Read(./.env)", "Bash(git push *)", "Read(./controle/recettes/**)"]
  }
}
```

- Format d'une règle : `Outil` ou `Outil(motif)`. `Bash(npm run *)` : toute commande qui commence par `npm run`.
- **Ordre d'évaluation : deny, puis ask, puis allow.** Un `deny` l'emporte toujours.
- Fichiers : `Read(./.env)`, `Edit(./src/**)`. `./` désigne le dossier de lancement ; `//` marque un chemin absolu. Vérifiez vos règles avec `/permissions`.
- `.claude/settings.json` est partagé (dans git) ; `.claude/settings.local.json` est personnel.
- Ne jamais utiliser le mode « bypass » ni `Bash` sans motif dans `allow`.

## Commandes Claude Code utiles aujourd'hui

| Commande | Usage |
|---|---|
| `claude --agent coordinateur` | session dont le fil principal est votre coordinateur |
| `claude -p "..."` | exécution sans interface (scripts, intégration continue) |
| `claude -p "..." --output-format json` | même chose, sortie exploitable par un programme |
| `/agents` | créer et gérer les agents |
| `/hooks` | voir les hooks actifs |
| `/permissions` | voir les règles actives |
| `/mcp` | voir les serveurs MCP connectés |
| `/context` | voir ce qui occupe le contexte |
| `/clear` | repartir d'un contexte vide entre deux tickets |
| `Maj+Tab` | alterner mode normal, acceptation des modifications et mode plan |

## Commandes de la chaîne

```bash
npm run controle -- doctor | check <n> | score <prénom> | phase rouge|vert|aucune
                     | worktree T-xx | reset T-xx | audit T-xx | mutants
```
