# Carte 7 : plan 30 jours

**Poste :** votre chaîne chez vous · **Début :** 16 h 30 · **Durée :** 12 min · **Contrôle :** `npm run controle -- check 7`

## Objectif

Repartir avec un **plan concret** pour installer cette chaîne sur votre vrai projet, avec des indicateurs pour savoir si elle marche.

## Livrable

`docs/plan-30-jours.md`, à partir du modèle ci-dessous.

## Cahier des charges

- Sept sections : **Contexte**, **Niveau d'autonomie visé**, **Semaine 1**, **Semaine 2**, **Semaines 3 et 4**, **Indicateurs**, **Risques et garde-fous**. Chacune d'au moins 120 caractères.
- **Niveau d'autonomie visé** : 1 à 4 (carte 3), pourquoi, et ce qui manque dans votre projet pour atteindre le suivant (CI, tests gelés, convention de branches...).
- **Contexte** : votre projet réel, sa taille, ses points de douleur, ce que les portes devront attraper en premier.
- Les semaines nomment des éléments **de votre chaîne d'aujourd'hui** (au moins trois skills ou agents cités par leur nom) et disent comment vous les adaptez à votre code.
- **Indicateurs** : au moins trois puces avec un **chiffre cible** (ex : « 60 % des tickets passent les portes du premier coup en semaine 4 »).
- **Risques et garde-fous** : ce que vous ne confierez pas à la ligne au début, et pourquoi.
- Méthode : demandez à Claude de **vous questionner** sur votre projet réel avant de rédiger. Un plan qui ne cite aucun fichier de votre dépôt est un plan générique.

## Modèle

```markdown
# Plan 30 jours

## Contexte
(Projet, taille de l'équipe, stack, point de douleur principal.)

## Niveau d'autonomie visé
(Niveau 1 à 4, pourquoi, prérequis manquants pour monter d'un niveau.)

## Semaine 1 : fondations
(Quoi mettre en place sur le vrai dépôt : CLAUDE.md, permissions, portes de base.)

## Semaine 2 : premiers skills et premières portes
(Lesquels de vos skills et agents d'aujourd'hui, adaptés comment.)

## Semaines 3 et 4 : production encadrée
(Premiers vrais tickets, niveau d'autonomie, revue humaine.)

## Indicateurs
- ...  (avec un chiffre cible)

## Risques et garde-fous
(Ce qu'on ne délègue pas encore, qui valide, comment on revient en arrière.)
```
