# Notes de frais

API de gestion de notes de frais (TypeScript, Fastify, Vitest). C'est le **chantier d'entraînement** de la journée « Workflow agentique ».
Vous n'êtes pas ici pour écrire du code à la main : vous êtes ici pour **construire la ligne de production** qui livre ce code, et la contrôler.

## Démarrer

```bash
npm install
npm test            # 32 tests verts attendus
npm run controle -- doctor
```

## Où trouver quoi

| Dossier | Contenu |
|---|---|
| `src/` | le code de l'API |
| `tests/` | les tests existants |
| `docs/` | règles métier, architecture, décisions (ADR), glossaire |
| `backlog/` | les tickets à produire (un fichier par ticket) |
| `cartes/` | **vos cartes de mission** (aussi en PDF) : suivez-les dans l'ordre, en commençant par `00-regles-du-jeu.md` |
| `controle/` | l'outillage de contrôle (ne pas modifier) |
| `.claude/` | **votre chaîne** : à construire pendant la journée |

## Les commandes de la chaîne

```bash
npm run controle -- doctor          # le poste est-il prêt ?
npm run controle -- check <n>       # contrôle qualité de la carte n (1 à 7)
npm run controle -- score prenom    # tableau de bord à coller dans le chat
npm run controle -- phase rouge     # fixe la phase de production (rouge, vert ou aucune)
npm run controle -- worktree T-07   # prépare un poste de travail isolé pour un ticket
npm run controle -- reset T-07      # supprime le poste et la branche pour recommencer
npm run controle -- audit T-07      # audit de la production d'un ticket
npm run controle -- mutants         # test de la solidité de vos tests
npm run gates                    # toutes les portes qualité
```
