import { describe, expect, it } from 'vitest';
import { construireApp } from '../src/app';

const MAINTENANT = new Date('2026-06-15T10:00:00Z');
const alice = { 'x-user-id': 'alice', 'x-role': 'employe' };
const bob = { 'x-user-id': 'bob', 'x-role': 'manager' };

function nouvelleApp() {
  return construireApp(() => MAINTENANT);
}

describe('API', () => {
  it('refuse une requête sans identité', async () => {
    const res = await nouvelleApp().inject({ method: 'POST', url: '/notes' });
    expect(res.statusCode).toBe(401);
  });

  it('crée une note puis y ajoute une ligne', async () => {
    const app = nouvelleApp();
    const creation = await app.inject({ method: 'POST', url: '/notes', headers: alice });
    expect(creation.statusCode).toBe(201);
    const { id } = creation.json();

    const ligne = await app.inject({
      method: 'POST',
      url: `/notes/${id}/lignes`,
      headers: alice,
      payload: {
        date: '2026-06-10',
        categorie: 'transport',
        montantHT: 4000,
        tauxTVA: 20,
        justificatif: true,
        libelle: 'Train',
      },
    });
    expect(ligne.statusCode).toBe(201);

    const lecture = await app.inject({ method: 'GET', url: `/notes/${id}`, headers: alice });
    expect(lecture.json().totalTTC).toBe(4800);
  });

  it('renvoie 422 pour une ligne au-dessus du plafond', async () => {
    const app = nouvelleApp();
    const { id } = (await app.inject({ method: 'POST', url: '/notes', headers: alice })).json();
    const res = await app.inject({
      method: 'POST',
      url: `/notes/${id}/lignes`,
      headers: alice,
      payload: {
        date: '2026-06-10',
        categorie: 'repas',
        montantHT: 9000,
        tauxTVA: 10,
        justificatif: true,
        libelle: 'Gala',
      },
    });
    expect(res.statusCode).toBe(422);
    expect(res.json().code).toBe('LIGNE_PLAFOND_DEPASSE');
  });

  it("renvoie 404 pour une note inconnue", async () => {
    const res = await nouvelleApp().inject({ method: 'GET', url: '/notes/NF-999', headers: bob });
    expect(res.statusCode).toBe(404);
  });
});
