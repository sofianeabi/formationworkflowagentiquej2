import { describe, expect, it } from 'vitest';
import { formaterEuros, ttc, tva } from '../src/money';

describe('money', () => {
  it('calcule la TVA à 20 % sur un montant rond', () => {
    expect(tva(10000, 20)).toBe(2000);
  });

  it('calcule le TTC', () => {
    expect(ttc(10000, 20)).toBe(12000);
  });

  it('ne taxe pas à 0 %', () => {
    expect(tva(5000, 0)).toBe(0);
  });

  it('formate des centimes en euros', () => {
    expect(formaterEuros(1250)).toBe('12,50 €');
    expect(formaterEuros(5)).toBe('0,05 €');
  });
});
