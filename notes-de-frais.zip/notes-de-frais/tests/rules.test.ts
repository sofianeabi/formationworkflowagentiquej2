import { describe, expect, it } from 'vitest';
import {
  ageEnJours,
  approbateurRequis,
  totalTTC,
  verifierLigne,
  verifierSoumission,
} from '../src/rules';
import type { LigneEntree, Note } from '../src/types';

const AUJOURDHUI = new Date('2026-06-15T10:00:00Z');

function ligne(surcharge: Partial<LigneEntree> = {}): LigneEntree {
  return {
    date: '2026-06-10',
    categorie: 'transport',
    montantHT: 1000,
    tauxTVA: 20,
    justificatif: true,
    libelle: 'Test',
    ...surcharge,
  };
}

describe('verifierLigne', () => {
  it('accepte une ligne valide', () => {
    expect(verifierLigne(ligne(), AUJOURDHUI)).toEqual([]);
  });

  it('refuse un montant nul ou non entier', () => {
    expect(verifierLigne(ligne({ montantHT: 0 }), AUJOURDHUI)).toEqual(['LIGNE_MONTANT_INVALIDE']);
    expect(verifierLigne(ligne({ montantHT: 10.5 }), AUJOURDHUI)).toEqual(['LIGNE_MONTANT_INVALIDE']);
  });

  it('refuse un repas au-dessus du plafond', () => {
    const erreurs = verifierLigne(ligne({ categorie: 'repas', montantHT: 4000 }), AUJOURDHUI);
    expect(erreurs).toContain('LIGNE_PLAFOND_DEPASSE');
  });

  it('exige un justificatif au-dessus du seuil', () => {
    const erreurs = verifierLigne(ligne({ montantHT: 5000, justificatif: false }), AUJOURDHUI);
    expect(erreurs).toContain('LIGNE_JUSTIFICATIF_MANQUANT');
  });

  it("n'exige pas de justificatif sous le seuil", () => {
    expect(verifierLigne(ligne({ montantHT: 1000, justificatif: false }), AUJOURDHUI)).toEqual([]);
  });

  it('refuse une date dans le futur', () => {
    expect(verifierLigne(ligne({ date: '2026-07-01' }), AUJOURDHUI)).toContain('LIGNE_DATE_FUTURE');
  });

  it('refuse une dépense trop ancienne', () => {
    expect(verifierLigne(ligne({ date: '2026-01-01' }), AUJOURDHUI)).toContain('LIGNE_TROP_ANCIENNE');
  });
});

describe('verifierSoumission', () => {
  it('refuse une note vide', () => {
    const note = { lignes: [] } as unknown as Note;
    expect(verifierSoumission(note, AUJOURDHUI)).toEqual(['NOTE_VIDE']);
  });
});

describe('ageEnJours et totalTTC', () => {
  it('calcule un âge en jours', () => {
    expect(ageEnJours('2026-06-10', AUJOURDHUI)).toBe(5);
  });

  it('additionne les TTC', () => {
    expect(totalTTC([{ montantHT: 1000, tauxTVA: 20 }, { montantHT: 1000, tauxTVA: 0 }])).toBe(2200);
  });
});

describe('approbateurRequis', () => {
  it('demande un manager pour un petit montant', () => {
    expect(approbateurRequis({ lignes: [{ montantHT: 1000, tauxTVA: 20 }] as never })).toBe('manager');
  });

  it('demande un directeur pour un gros montant', () => {
    expect(approbateurRequis({ lignes: [{ montantHT: 100000, tauxTVA: 20 }] as never })).toBe('directeur');
  });
});
