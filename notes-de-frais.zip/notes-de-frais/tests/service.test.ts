import { beforeEach, describe, expect, it } from 'vitest';
import { ErreurMetier } from '../src/errors';
import { NoteService } from '../src/service';
import { Store } from '../src/store';
import type { LigneEntree, Utilisateur } from '../src/types';

const MAINTENANT = new Date('2026-06-15T10:00:00Z');
const alice: Utilisateur = { id: 'alice', role: 'employe' };
const bob: Utilisateur = { id: 'bob', role: 'manager' };
const diane: Utilisateur = { id: 'diane', role: 'directeur' };
const carl: Utilisateur = { id: 'carl', role: 'comptable' };

const LIGNE: LigneEntree = {
  date: '2026-06-10',
  categorie: 'transport',
  montantHT: 4000,
  tauxTVA: 20,
  justificatif: true,
  libelle: 'Train',
};

let service: NoteService;

beforeEach(() => {
  service = new NoteService(new Store(), () => MAINTENANT);
});

function noteSoumise(montantHT = 4000) {
  const note = service.creer(alice);
  service.ajouterLigne(alice, note.id, { ...LIGNE, montantHT });
  service.soumettre(alice, note.id);
  return note;
}

function codeErreur(fn: () => unknown): string | undefined {
  try {
    fn();
  } catch (e) {
    return e instanceof ErreurMetier ? e.code : 'AUTRE';
  }
  return undefined;
}

describe('cycle de vie', () => {
  it('crée un brouillon', () => {
    const note = service.creer(alice);
    expect(note.statut).toBe('brouillon');
    expect(note.employeId).toBe('alice');
  });

  it('soumet une note valide', () => {
    expect(noteSoumise().statut).toBe('soumise');
  });

  it("refuse de soumettre une note vide", () => {
    const note = service.creer(alice);
    expect(codeErreur(() => service.soumettre(alice, note.id))).toBe('NOTE_VIDE');
  });

  it('un manager approuve une note soumise', () => {
    const note = noteSoumise();
    expect(service.approuver(bob, note.id).statut).toBe('approuvee');
  });

  it('un manager ne peut pas approuver sa propre note', () => {
    const note = service.creer(bob);
    service.ajouterLigne(bob, note.id, LIGNE);
    service.soumettre(bob, note.id);
    expect(codeErreur(() => service.approuver(bob, note.id))).toBe('AUTO_APPROBATION');
  });

  it('un employé ne peut pas approuver', () => {
    const note = noteSoumise();
    expect(codeErreur(() => service.approuver(alice, note.id))).toBe('ROLE_INSUFFISANT');
  });

  it('un manager ne peut pas approuver un gros montant', () => {
    const note = noteSoumise(60000);
    expect(codeErreur(() => service.approuver(bob, note.id))).toBe('ROLE_INSUFFISANT');
    expect(service.approuver(diane, note.id).statut).toBe('approuvee');
  });

  it('rejette avec un motif', () => {
    const note = noteSoumise();
    const rejetee = service.rejeter(bob, note.id, 'Justificatif illisible');
    expect(rejetee.statut).toBe('rejetee');
    expect(rejetee.motifRejet).toBe('Justificatif illisible');
  });

  it('refuse un rejet sans motif', () => {
    const note = noteSoumise();
    expect(codeErreur(() => service.rejeter(bob, note.id, ''))).toBe('MOTIF_REQUIS');
  });

  it('le comptable rembourse une note approuvée', () => {
    const note = noteSoumise();
    service.approuver(bob, note.id);
    expect(service.rembourser(carl, note.id).statut).toBe('remboursee');
  });
});

describe('accès', () => {
  it("un employé ne voit pas la note d'un autre", () => {
    const note = service.creer(alice);
    const autre: Utilisateur = { id: 'eve', role: 'employe' };
    expect(codeErreur(() => service.consulter(autre, note.id))).toBe('ACCES_REFUSE');
  });

  it('filtre par statut', () => {
    noteSoumise();
    service.creer(alice);
    expect(service.lister(alice, 'soumise')).toHaveLength(1);
  });
});
