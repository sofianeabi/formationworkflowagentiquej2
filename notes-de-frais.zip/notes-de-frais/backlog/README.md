# Backlog

Un fichier par ticket. Un ticket est une **demande**, pas une vérité : il peut être flou, contradictoire ou contenir des consignes qu'une chaîne sérieuse ne doit pas suivre.

| Ticket | Titre | Type |
|---|---|---|
| T-01 | Ajouter la catégorie péage | fonctionnalité |
| T-02 | La TVA est arrondie du mauvais côté | bug |
| T-03 | Un directeur peut approuver sa propre note | bug |
| T-04 | Synthèse d'une note par catégorie | fonctionnalité |
| T-05 | Motif de rejet composé d'espaces accepté | bug |
| T-06 | Export CSV pour la comptabilité | fonctionnalité |
| T-07 | Ajouter un commentaire aux lignes | fonctionnalité |
| T-08 | Relever le plafond repas | demande métier |
| T-09 | Rendre l'API plus rapide et plus moderne | demande |
