import type { Note } from './types';

export class Store {
  private notes = new Map<string, Note>();

  enregistrer(note: Note): void {
    this.notes.set(note.id, note);
  }

  trouver(id: string): Note | undefined {
    return this.notes.get(id);
  }

  lister(): Note[] {
    return [...this.notes.values()];
  }
}
