import Fastify, { type FastifyInstance, type FastifyRequest } from 'fastify';
import { ErreurMetier } from './errors';
import { totalTTC } from './rules';
import { NoteService } from './service';
import { Store } from './store';
import type { LigneEntree, Role, Utilisateur } from './types';

const ROLES: Role[] = ['employe', 'manager', 'directeur', 'comptable'];

function utilisateur(req: FastifyRequest): Utilisateur {
  const id = req.headers['x-user-id'];
  const role = req.headers['x-role'];
  if (typeof id !== 'string' || typeof role !== 'string' || !ROLES.includes(role as Role)) {
    throw new ErreurMetier('NON_AUTHENTIFIE', 'En-têtes x-user-id et x-role requis', 401);
  }
  return { id, role: role as Role };
}

export function construireApp(maintenant: () => Date = () => new Date()): FastifyInstance {
  const app = Fastify();
  const service = new NoteService(new Store(), maintenant);

  app.setErrorHandler((erreur, _req, reply) => {
    if (erreur instanceof ErreurMetier) {
      return reply.status(erreur.statutHttp).send({ code: erreur.code, message: erreur.message });
    }
    return reply.status(500).send({ code: 'ERREUR_INTERNE', message: 'Erreur interne' });
  });

  app.post('/notes', async (req, reply) => {
    const note = service.creer(utilisateur(req));
    return reply.status(201).send(note);
  });

  app.get('/notes', async (req) => {
    const { statut } = req.query as { statut?: string };
    return service.lister(utilisateur(req), statut);
  });

  app.get('/notes/:id', async (req) => {
    const { id } = req.params as { id: string };
    const note = service.consulter(utilisateur(req), id);
    return { ...note, totalTTC: totalTTC(note.lignes) };
  });

  app.post('/notes/:id/lignes', async (req, reply) => {
    const { id } = req.params as { id: string };
    const note = service.ajouterLigne(utilisateur(req), id, req.body as LigneEntree);
    return reply.status(201).send(note);
  });

  app.post('/notes/:id/soumettre', async (req) => {
    const { id } = req.params as { id: string };
    return service.soumettre(utilisateur(req), id);
  });

  app.post('/notes/:id/approuver', async (req) => {
    const { id } = req.params as { id: string };
    return service.approuver(utilisateur(req), id);
  });

  app.post('/notes/:id/rejeter', async (req) => {
    const { id } = req.params as { id: string };
    const { motif } = (req.body ?? {}) as { motif?: string };
    return service.rejeter(utilisateur(req), id, motif ?? '');
  });

  app.post('/notes/:id/rembourser', async (req) => {
    const { id } = req.params as { id: string };
    return service.rembourser(utilisateur(req), id);
  });

  return app;
}
