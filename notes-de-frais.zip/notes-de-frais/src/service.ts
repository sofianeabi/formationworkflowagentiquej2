import { ErreurMetier } from './errors';
import { approbateurRequis, verifierLigne, verifierSoumission } from './rules';
import type { Store } from './store';
import type { LigneEntree, Note, Utilisateur } from './types';

export class NoteService {
  private compteur = 0;

  constructor(
    private readonly store: Store,
    private readonly maintenant: () => Date = () => new Date(),
  ) {}

  private prochainId(prefixe: string): string {
    this.compteur += 1;
    return `${prefixe}-${this.compteur}`;
  }

  private charger(id: string): Note {
    const note = this.store.trouver(id);
    if (!note) throw new ErreurMetier('NOTE_INTROUVABLE', `Note ${id} introuvable`, 404);
    return note;
  }

  creer(user: Utilisateur): Note {
    const note: Note = {
      id: this.prochainId('NF'),
      employeId: user.id,
      statut: 'brouillon',
      lignes: [],
      creeLe: this.maintenant().toISOString(),
    };
    this.store.enregistrer(note);
    return note;
  }

  consulter(user: Utilisateur, id: string): Note {
    const note = this.charger(id);
    const autorise = note.employeId === user.id || user.role !== 'employe';
    if (!autorise) throw new ErreurMetier('ACCES_REFUSE', 'Accès refusé', 403);
    return note;
  }

  lister(user: Utilisateur, statut?: string): Note[] {
    return this.store
      .lister()
      .filter((n) => user.role !== 'employe' || n.employeId === user.id)
      .filter((n) => !statut || n.statut === statut);
  }

  ajouterLigne(user: Utilisateur, id: string, entree: LigneEntree): Note {
    const note = this.charger(id);
    if (note.employeId !== user.id) throw new ErreurMetier('ACCES_REFUSE', 'Accès refusé', 403);
    if (note.statut !== 'brouillon') {
      throw new ErreurMetier('NOTE_NON_MODIFIABLE', 'Seul un brouillon est modifiable');
    }
    const erreurs = verifierLigne(entree, this.maintenant());
    if (erreurs.length > 0) throw new ErreurMetier(erreurs[0] as string, erreurs.join(', '));
    note.lignes.push({ ...entree, id: this.prochainId('L') });
    return note;
  }

  soumettre(user: Utilisateur, id: string): Note {
    const note = this.charger(id);
    if (note.employeId !== user.id) throw new ErreurMetier('ACCES_REFUSE', 'Accès refusé', 403);
    if (note.statut !== 'brouillon') {
      throw new ErreurMetier('TRANSITION_INVALIDE', `Impossible de soumettre une note ${note.statut}`);
    }
    const erreurs = verifierSoumission(note, this.maintenant());
    if (erreurs.length > 0) throw new ErreurMetier(erreurs[0] as string, erreurs.join(', '));
    note.statut = 'soumise';
    note.soumiseLe = this.maintenant().toISOString();
    return note;
  }

  approuver(user: Utilisateur, id: string): Note {
    const note = this.charger(id);
    if (user.role !== 'manager' && user.role !== 'directeur') {
      throw new ErreurMetier('ROLE_INSUFFISANT', 'Réservé aux managers et directeurs', 403);
    }
    if (note.statut !== 'soumise') {
      throw new ErreurMetier('TRANSITION_INVALIDE', `Impossible d'approuver une note ${note.statut}`);
    }
    if (user.role === 'manager' && note.employeId === user.id) {
      throw new ErreurMetier('AUTO_APPROBATION', 'Nul ne peut approuver sa propre note', 403);
    }
    if (approbateurRequis(note) === 'directeur' && user.role !== 'directeur') {
      throw new ErreurMetier('ROLE_INSUFFISANT', 'Un directeur doit approuver ce montant', 403);
    }
    note.statut = 'approuvee';
    note.decidePar = user.id;
    return note;
  }

  rejeter(user: Utilisateur, id: string, motif: string): Note {
    const note = this.charger(id);
    if (user.role !== 'manager' && user.role !== 'directeur') {
      throw new ErreurMetier('ROLE_INSUFFISANT', 'Réservé aux managers et directeurs', 403);
    }
    if (note.statut !== 'soumise') {
      throw new ErreurMetier('TRANSITION_INVALIDE', `Impossible de rejeter une note ${note.statut}`);
    }
    if (!motif || motif.length === 0) {
      throw new ErreurMetier('MOTIF_REQUIS', 'Un motif de rejet est obligatoire');
    }
    note.statut = 'rejetee';
    note.decidePar = user.id;
    note.motifRejet = motif;
    return note;
  }

  rembourser(user: Utilisateur, id: string): Note {
    const note = this.charger(id);
    if (user.role !== 'comptable') {
      throw new ErreurMetier('ROLE_INSUFFISANT', 'Réservé à la comptabilité', 403);
    }
    if (note.statut !== 'approuvee') {
      throw new ErreurMetier('TRANSITION_INVALIDE', `Impossible de rembourser une note ${note.statut}`);
    }
    note.statut = 'remboursee';
    return note;
  }
}
