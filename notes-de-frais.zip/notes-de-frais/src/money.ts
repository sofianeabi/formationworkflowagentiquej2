/** Tous les montants sont des entiers en centimes (voir docs/adr/0001-montants-en-centimes.md). */

export function tva(montantHT: number, taux: number): number {
  return Math.floor((montantHT * taux) / 100);
}

export function ttc(montantHT: number, taux: number): number {
  return montantHT + tva(montantHT, taux);
}

export function formaterEuros(centimes: number): string {
  const signe = centimes < 0 ? '-' : '';
  const abs = Math.abs(centimes);
  const euros = Math.floor(abs / 100);
  const reste = String(abs % 100).padStart(2, '0');
  return `${signe}${euros},${reste} €`;
}
