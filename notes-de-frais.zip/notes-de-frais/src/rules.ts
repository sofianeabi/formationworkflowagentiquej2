import { ttc } from './money';
import type { Categorie, Ligne, LigneEntree, Note, Role } from './types';

/** Plafond TTC par ligne, en centimes. null = pas de plafond. */
export const PLAFONDS: Record<Categorie, number | null> = {
  repas: 3000,
  hotel: 12000,
  transport: null,
  autre: 5000,
};

/** Au-dessus de ce montant TTC (strictement), un justificatif est obligatoire. */
export const SEUIL_JUSTIFICATIF = 2500;
/** Au-dessus de ce total TTC (strictement), seul un directeur peut approuver. */
export const SEUIL_DIRECTEUR = 50000;
/** Une dépense ne peut pas être soumise plus de 60 jours après sa date. */
export const DELAI_MAX_JOURS = 60;

const MS_PAR_JOUR = 24 * 60 * 60 * 1000;

export function jourIso(date: Date): string {
  return date.toISOString().slice(0, 10);
}

export function ageEnJours(dateLigne: string, aujourdhui: Date): number {
  const debut = Date.parse(`${dateLigne}T00:00:00Z`);
  const fin = Date.parse(`${jourIso(aujourdhui)}T00:00:00Z`);
  return Math.round((fin - debut) / MS_PAR_JOUR);
}

export function totalTTC(lignes: Pick<Ligne, 'montantHT' | 'tauxTVA'>[]): number {
  return lignes.reduce((somme, l) => somme + ttc(l.montantHT, l.tauxTVA), 0);
}

export function verifierLigne(ligne: LigneEntree, aujourdhui: Date): string[] {
  const erreurs: string[] = [];
  if (!Number.isInteger(ligne.montantHT) || ligne.montantHT <= 0) {
    erreurs.push('LIGNE_MONTANT_INVALIDE');
    return erreurs;
  }
  const montantTTC = ttc(ligne.montantHT, ligne.tauxTVA);
  const plafond = PLAFONDS[ligne.categorie];
  if (plafond !== null && montantTTC > plafond) {
    erreurs.push('LIGNE_PLAFOND_DEPASSE');
  }
  if (montantTTC > SEUIL_JUSTIFICATIF && !ligne.justificatif) {
    erreurs.push('LIGNE_JUSTIFICATIF_MANQUANT');
  }
  if (ligne.date > jourIso(aujourdhui)) {
    erreurs.push('LIGNE_DATE_FUTURE');
  }
  if (ageEnJours(ligne.date, aujourdhui) > DELAI_MAX_JOURS) {
    erreurs.push('LIGNE_TROP_ANCIENNE');
  }
  return erreurs;
}

export function verifierSoumission(note: Note, aujourdhui: Date): string[] {
  if (note.lignes.length === 0) return ['NOTE_VIDE'];
  return note.lignes.flatMap((l) => verifierLigne(l, aujourdhui));
}

export function approbateurRequis(note: Pick<Note, 'lignes'>): Role {
  return totalTTC(note.lignes) > SEUIL_DIRECTEUR ? 'directeur' : 'manager';
}
