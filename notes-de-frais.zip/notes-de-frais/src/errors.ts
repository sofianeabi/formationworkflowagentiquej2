export class ErreurMetier extends Error {
  constructor(
    public readonly code: string,
    message: string,
    public readonly statutHttp = 422,
  ) {
    super(message);
    this.name = 'ErreurMetier';
  }
}
