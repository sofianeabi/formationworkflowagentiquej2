export type Categorie = 'repas' | 'hotel' | 'transport' | 'autre';
export type TauxTVA = 0 | 5.5 | 10 | 20;
export type Statut = 'brouillon' | 'soumise' | 'approuvee' | 'rejetee' | 'remboursee';
export type Role = 'employe' | 'manager' | 'directeur' | 'comptable';

export interface Utilisateur {
  id: string;
  role: Role;
}

export interface Ligne {
  id: string;
  /** Date de la dépense, format AAAA-MM-JJ. */
  date: string;
  categorie: Categorie;
  /** Montant hors taxe en centimes (entier). */
  montantHT: number;
  tauxTVA: TauxTVA;
  justificatif: boolean;
  libelle: string;
}

export interface Note {
  id: string;
  employeId: string;
  statut: Statut;
  lignes: Ligne[];
  creeLe: string;
  soumiseLe?: string;
  decidePar?: string;
  motifRejet?: string;
}

export type LigneEntree = Omit<Ligne, 'id'>;
