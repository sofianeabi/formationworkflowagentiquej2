import { construireApp } from './app';

const app = construireApp();
const port = Number(process.env.PORT ?? 3000);

app.listen({ port, host: '0.0.0.0' }).catch((erreur) => {
  console.error(erreur);
  process.exit(1);
});
